CREATE TABLE CREDENTIALS (userId VARCHAR(255) NOT NULL, password VARCHAR(255), role VARCHAR(255), PRIMARY KEY (userId))
CREATE TABLE incident (incident_id BIGINT AUTO_INCREMENT NOT NULL, end_Time DATETIME, incident VARCHAR(255), start_time DATETIME, status VARCHAR(255), resident_id BIGINT, staff_id BIGINT, PRIMARY KEY (incident_id))
CREATE TABLE resident (resident_id BIGINT AUTO_INCREMENT NOT NULL, address1 VARCHAR(255), address2 VARCHAR(255), city VARCHAR(255), email1 VARCHAR(255), first_name VARCHAR(255), last_name VARCHAR(255), middle_name VARCHAR(255), phone1 VARCHAR(255), photo VARCHAR(255), state VARCHAR(255), status VARCHAR(255), zipcode VARCHAR(255), PRIMARY KEY (resident_id))
CREATE TABLE staff (staff_id BIGINT NOT NULL, address1 VARCHAR(255), address2 VARCHAR(255), city VARCHAR(255), email1 VARCHAR(255), first_name VARCHAR(255), last_name VARCHAR(255), middle_name VARCHAR(255), phone1 VARCHAR(255), photo VARCHAR(255), role VARCHAR(255), state VARCHAR(255), status VARCHAR(255), userid VARCHAR(255), zipcode VARCHAR(255), PRIMARY KEY (staff_id))
CREATE TABLE service (service_id BIGINT NOT NULL, service VARCHAR(255), avg_time INTEGER, start_time DATETIME, resident_id BIGINT, staff_id BIGINT, PRIMARY KEY (service_id))
ALTER TABLE incident ADD CONSTRAINT FK_incident_staff_id FOREIGN KEY (staff_id) REFERENCES staff (staff_id)
ALTER TABLE incident ADD CONSTRAINT FK_incident_resident_id FOREIGN KEY (resident_id) REFERENCES resident (resident_id)
ALTER TABLE service ADD CONSTRAINT FK_service_resident_id FOREIGN KEY (resident_id) REFERENCES resident (resident_id)
ALTER TABLE service ADD CONSTRAINT FK_service_staff_id FOREIGN KEY (staff_id) REFERENCES staff (staff_id)
CREATE TABLE SEQUENCE (SEQ_NAME VARCHAR(50) NOT NULL, SEQ_COUNT DECIMAL(38), PRIMARY KEY (SEQ_NAME))
INSERT INTO SEQUENCE(SEQ_NAME, SEQ_COUNT) values ('SEQ_GEN', 0)

Insert into credentials 
(password, 															role,	userid,) values 
('$2a$10$ddkmy83h6Z9o1icmUBjaUucEbRJBXQ8V6WMuQ7Eq.QTSw9Fy1xj1C', 	'ADMIN','bgirardo'),
('$2a$10$vUqcDlpvdoypPbKf9FvxAu7LMV3tRQBaAPcpGve/BlXOrZ/R.uajy', 	'RA', 	'lgirardo'),
("", 																'ADMIN','scrosby'),
('$2a$10$vUqcDlpvdoypPbKf9FvxAu7LMV3tRQBaAPcpGve/BlXOrZ/R.uajy', 	'RA',    'ralph');


insert into resident 
(resident_id, 		address1,        	address2, 	city,      email1,        		first_name, last_name,  middle_name,  phone1,         state, status,     zipcode, photo) values
(1, 			'19304 Warrington', 	'',    		'Detroit', 'pgirardo@aol.com', 	'Mary',     'Girardot', 'Margaret',  '(313) 323-1173', 'MI',  'Deceased', '48187', 'RS-000001.JPG'),
(2, 			'33555 Westfield', 		'',     	'Redford', 'millie@yahoo.com', 	'Mildred',  'Holder',   '',          '(313) 555-1173', 'MI',  'Deceased', '48188', 'RS-000002.JPG');

insert into staff     
(staff_id, 	address1,          address2, 	city,      email1,                		first_name, 	last_name,    middle_name, 		phone1,            role,      state, status, userid, zipcode, photo) values 
(1,        	'1492 Hendire'   ,   '', 		'Canton' , 'bgirardo@gmail.com'			,  	'Bernard'	,  'Girardot',   'J',          '(734) 776-2813',  'Admin',   'MI', 'ACTIVE', 'bgirardo',  '48187', 'ST-000001.JPG'),
(2,        	'1492 Hendire'   ,   '', 		'Canton' , 'lgirardot@ftbsystems.com'	,   'Lori'   	,  'Girardot',   'P',          '(734) 776-9078',  'RA',      'MI', 'ACTIVE', 'lgirardo',  '48187', 'ST-000002.JPG'),
(3,			'12345 Hunter'	 ,   '', 		'Saline' , 'aadams6@ford.com'			, 	'Ann'    	,  'Adams',      'M',          '(313) 555-1212',  'RA',      'MI', 'ACTIVE', 'aadams6',   '48111', 'ST-000003.JPG'),                                          
(4,        	'12345 Elm'      ,   '', 		'Anytown', 'raph@gmail.com'				,  	'Ralph'		,  'Kramdom',    'M',          '(734) 555-7878',  'RA',      'MI', 'ACTIVE', 'ralph'   ,  '12345', 'ST-000004.JPG');


insert into incident
(incident_id, incident, 	start_time, 	status, staff_id, resident_id) values 	
(1, 		'Seizure', 		now(),	'OPEN', 		2,		1),
(2, 		'Fall', 		now(),	'Closed',		2,		1),
(3, 		'Aggression', 	now(), 	'Closed',		3,		2),
(4, 		'Faint', 		now(),	'Open', 		4,		2);

insert into service
(service_id, 	start_Time, 	Service, 				staff_id, 	resident_id 	) values 
(1, 	now(), 		'Escorted', 				1,		1),
(2, 	now(), 		'Dressed', 				2, 		2),
( 3, 	now(), 		'Assisted with Dinning', 		4, 		2),
( 4, 	now(), 		'Cleaned Room', 			4, 		1);

