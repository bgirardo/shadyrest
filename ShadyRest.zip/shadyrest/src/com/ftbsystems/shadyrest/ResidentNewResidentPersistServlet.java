package com.ftbsystems.shadyrest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ResidentNewResidentPersistServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ResidentNewResidentPersistServlet" })
public class ResidentNewResidentPersistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ResidentNewResidentPersistServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Resident thisResident = new Resident();
		thisResident.setFirstName(request.getParameter("firstname")); // lets move the info from the web page into the
																		// object
		thisResident.setLastName(request.getParameter("lastname"));
		thisResident.setMiddleName(request.getParameter("middlename"));
		thisResident.setAddress1(request.getParameter("address1"));
		thisResident.setAddress2(request.getParameter("address2"));
		thisResident.setCity(request.getParameter("city"));
		thisResident.setState(request.getParameter("state"));
		thisResident.setEmail1(request.getParameter("email1"));
		thisResident.setPhone1(request.getParameter("phone1"));
		thisResident.setPhoto(request.getParameter("photo"));
		thisResident.setStatus(request.getParameter("status"));
		ResidentServices nrs = new ResidentServices();
		nrs.em.getTransaction().begin(); // lets save the info!
		nrs.em.persist(thisResident);
		nrs.em.getTransaction().commit(); // done!
		RequestDispatcher dispatcher = request.getRequestDispatcher("ResidentMultiListing.jsp");
		dispatcher.forward(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
