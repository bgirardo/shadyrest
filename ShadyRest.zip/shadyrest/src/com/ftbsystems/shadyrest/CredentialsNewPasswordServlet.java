package com.ftbsystems.shadyrest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Servlet implementation class CredentialsNewPasswordServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/CredentialsNewPasswordServlet" })
public class CredentialsNewPasswordServlet extends HttpServlet  {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/*
	 * CredentialsNewPasswordServlet.Java
	 * 
	 * Called by Password.jsp Forwards to index.jsp
	 * 
	 * Takes a user id and password, finds the credentials for the user, validates
	 * (if necessary) and updates the password field.
	 * 
	 * Written on March 1, 2020 Updated on March 9, 2020
	 * 
	 */
	public CredentialsNewPasswordServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// lets check to see if the user has an old password - and if so - validate it.
		// if no old password (1st time user) - make 'em add one.

		// lets get the parameters from the last screen.
		FunctionalInterface pwl = (String x)->(x.length()>7);    // lambda defined

		String userID = request.getParameter("userId");
		String oldPW = request.getParameter("OldPW");
		String newPassword = request.getParameter("password1");
		System.out.println("CredentialsNewPasswordServlet says UserID = :" + userID + ":");
		Boolean isValid = pwl.passwordLength(newPassword);    // lambda called.
		System.out.println("CredentialsNewPasswordSErvlet says:  isValid = " + isValid);
		/*
		 * String userId = request.getParameter("userId");
		 * System.out.println("CredentialsNewPasswordSErvlet says userId = :" + userId +
		 * ":");
		 */

		// fire up the factory.
		CredentialServices ncs = new CredentialServices();

		// go grab the user's credentials
		Credentials userCredentials = null;
		try {
			userCredentials = ncs.getCredentials(userID);
		} catch (CredentialsMissingException e) {

			e.printStackTrace();
		}

		if (userCredentials == null) {
			System.out.println("Null Credentials!");
		}

		// OK - lets see of things are what they seem to be!
		Boolean valid = false;
		if ((oldPW == null) || (oldPW.contentEquals(""))) {
			valid = true; // first time user
		} else {
			System.out.println(":" + oldPW + ":");
			System.out.println("----------------------------------------");
			valid = BCrypt.checkpw(oldPW, userCredentials.getPassword()); // had a password - do they remember it?
		}

		if (valid = true) {
			System.out.println("Setting new password!");
			// add some salt and hash the new password ...
			String salt = BCrypt.gensalt();
			String hashed = BCrypt.hashpw(newPassword, salt);
			System.out.println(hashed);
			userCredentials.setPassword(hashed);
			ncs.saveCredentials(userCredentials);
		}
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 
		doGet(request, response);
	}

/*	@Override
	public Boolean passwordLength(String testPassword) {
		return null;
	}
*/
}
