package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class IncidentServlet
 *
 * @web.servlet name="IncidentServlet" display-name="IncidentServlet"
 *
 * @web.servlet-mapping url-pattern="/IncidentServlet"
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/IncidentServlet" })
public class IncidentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/*
	 * @Author Bernard J. Girardot
	 * 
	 * Written around December 20, 2019
	 * 
	 * 
	 * 
	 */
	public IncidentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/*
	 * IncidentServlet.java
	 * 
	 * A servlet that takes an Incident ID as a parameter, retrieves the incident
	 * and then uses Incident.jsp page to present the object for editing.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		if (role == null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		if (role.contentEquals("RA")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		if (role.contentEquals("ADMIN")) {

			String myParams = request.getParameter("IncidentID");
			IncidentServices nis = new IncidentServices();
			Long myId = Long.parseLong(myParams);
			Incident thisIncident = nis.getIncidentById(myId);
			request.setAttribute("incident", thisIncident);
			RequestDispatcher dispatcher = request.getRequestDispatcher("Incident.jsp");
			dispatcher.forward(request, response);
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
