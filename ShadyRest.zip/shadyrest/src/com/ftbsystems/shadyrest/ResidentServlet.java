package com.ftbsystems.shadyrest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ResidentServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ResidentServlet" })
public class ResidentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ResidentServlet() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/*
	 * ResidentServlet.java
	 * 
	 * This class controls wether a user is entering a "New Resident", or is
	 * "Editing" a known resident. If the parameter "ResidentID" exists and is
	 * filled, then we are going to go get the resident, and let the end-user edit
	 * it.
	 * 
	 * If the parameter "ResidentID" is empty or doesn't exist, then we will create
	 * a new resident, and let the end-user edity the "New Blank" resident.
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		if (role == null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		if (role.contentEquals("RA")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		if (role.contentEquals("ADMIN")) {

			String myParams = request.getParameter("ResidentID"); // Try to get the Parameter
			ResidentServices nrs = new ResidentServices(); // Fire up the database factory!
			Resident thisResident; // we'll need a resident ... but do we link it to an existing or grab a new?
			System.out.println("The next line is what's being complained about: " + myParams);
			if (myParams != null) { // OK - We hava a Parameter! - link to an existing
				Long myId = Long.parseLong(myParams); // it was a string - so lets make it a long
				thisResident = nrs.getResidentById(myId); // go grab them!
			} else {
				thisResident = new Resident(); // ok - we need to "gen up" a new resident.
				thisResident.setResidentId(0L); // flag it as "new"
			}

			request.setAttribute("Resident", thisResident); // put the resident onto "request"
			RequestDispatcher dispatcher = request.getRequestDispatcher("Resident.jsp"); // send it down the tube!
			dispatcher.forward(request, response);
			response.getWriter().append("Served at: ").append(request.getContextPath());

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
