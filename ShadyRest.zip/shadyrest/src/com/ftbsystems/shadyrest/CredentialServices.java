/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.util.List;

import javax.mail.Session;
import javax.persistence.NamedQuery;
import javax.persistence.Query;

/**
 * @author Bernard Girardot
 *
 */

/*
 * CredentialServices.java
 * 
 * This class extends the AbstractServices class and provides persistence
 * services for Credentials.
 * 
 * Written on February 15, 2020 by Bernard J. Girardot for Per Scholars Java
 * Full Stack Developer
 * 
 * Revised March 10, 2020 to change the primary key and eliminate unnecessary
 * columns.
 * 
 */

// note:  named queriest are copied over from the entity for convenience.
// @NamedQuery(name="credentials.getUser",     query="SELECT c from Credentials c WHERE c.userId=:userid")
public class CredentialServices extends AbstractServices {

	public CredentialServices() {

	}

	public Credentials getCredentials(String userid) throws CredentialsMissingException { // custom execption.
		Credentials theseCredentials = em.find(Credentials.class, userid);
		if (theseCredentials==null){
			throw new CredentialsMissingException("Could not find credentials for " + userid);
		}
		return theseCredentials;
	}
	public void saveCredentials(Credentials theseCredentials) {
		em.getTransaction().begin();
		em.persist(theseCredentials);
		em.getTransaction().commit();
	}
}
