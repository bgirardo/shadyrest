/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.io.Serializable;
import java.lang.annotation.Target;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Bernard Girardot
 *
 */

/*
 * Staff.java
 * 
 * Managed Entity representing "Staff" members.
 * 
 */
@Entity
@Table(name = "staff")
@NamedQueries({ @NamedQuery(name = "getStaffById", query = "SELECT s from Staff s where s.staffId=:Id"),
		@NamedQuery(name = "getAllStaff", query = "SELECT s from Staff s") })
public class Staff implements Serializable {
	private static final long serialVersionUID = 7L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "staff_id")
	private Long staffId;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "middle_name")
	private String middleName;

	@Column(name = "address1")
	private String address1;

	@Column(name = "address2")
	private String address2;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "zipcode")
	private String zipCode;

	@Column(name = "phone1")
	private String phone1;

	@Column(name = "email1")
	private String email1;

	@Column(name = "photo")
	private String photo;

	@Column(name = "status")
	private String status;

	@Column(name = "userid")
	private String userid;

	@Column(name = "role")
	private String role;

	public Staff() {

	}

	/**
	 * @param lastName
	 * @param firstName
	 * @param middleName
	 * @param address1
	 * @param address2
	 * @param city
	 * @param state
	 * @param zipCode
	 * @param phone1
	 * @param email1
	 * @param photo
	 * @param status
	 * @param userid
	 * @param role
	 */
	public Staff(String lastName, String firstName, String middleName, String address1, String address2, String city,
			String state, String zipCode, String phone1, String email1, String photo, String status, String userid,
			String role) {
		this.setLastName(lastName);
		this.setFirstName(firstName);
		this.setMiddleName(middleName);
		this.setAddress1(address1);
		this.setAddress2(address2);
		this.setCity(city);
		this.setState(state);
		this.setZipCode(zipCode);
		this.setPhone1(phone1);
		this.setEmail1(email1);
		this.setPhoto(photo);
		this.setStatus(status);
		this.setUserid(userid);
		this.setRole(role);
	}

	/**
	 * @return the staffId
	 */
	public Long getStaffId() {
		return staffId;
	}

	/**
	 * @param staffId the staffId to set
	 */
	public void setStaffId(Long staffId) {
		this.staffId = staffId;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the phone1
	 */
	public String getPhone1() {
		return phone1;
	}

	/**
	 * @param phone1 the phone1 to set
	 */
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	/**
	 * @return the email1
	 */
	public String getEmail1() {
		return email1;
	}

	/**
	 * @param email1 the email1 to set
	 */
	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	/**
	 * @return the photo
	 */
	public String getPhoto() {
		return photo;
	}

	/**
	 * @param photo the photo to set
	 */
	public void setPhoto(String photo) {
		this.photo = photo;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the userid
	 */
	public String getUserid() {
		return userid;
	}

	/**
	 * @param userid the userid to set
	 */
	public void setUserid(String userid) {
		this.userid = userid;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Staff [");
		if (staffId != null) {
			builder.append("staffId=");
			builder.append(staffId);
			builder.append(", ");
		}
		if (lastName != null) {
			builder.append("lastName=");
			builder.append(lastName);
			builder.append(", ");
		}
		if (firstName != null) {
			builder.append("firstName=");
			builder.append(firstName);
			builder.append(", ");
		}
		if (middleName != null) {
			builder.append("middleName=");
			builder.append(middleName);
			builder.append(", ");
		}
		if (address1 != null) {
			builder.append("address1=");
			builder.append(address1);
			builder.append(", ");
		}
		if (address2 != null) {
			builder.append("address2=");
			builder.append(address2);
			builder.append(", ");
		}
		if (city != null) {
			builder.append("city=");
			builder.append(city);
			builder.append(", ");
		}
		if (state != null) {
			builder.append("state=");
			builder.append(state);
			builder.append(", ");
		}
		if (zipCode != null) {
			builder.append("zipCode=");
			builder.append(zipCode);
			builder.append(", ");
		}
		if (phone1 != null) {
			builder.append("phone1=");
			builder.append(phone1);
			builder.append(", ");
		}
		if (email1 != null) {
			builder.append("email1=");
			builder.append(email1);
			builder.append(", ");
		}
		if (photo != null) {
			builder.append("photo=");
			builder.append(photo);
			builder.append(", ");
		}
		if (status != null) {
			builder.append("status=");
			builder.append(status);
			builder.append(", ");
		}
		if (userid != null) {
			builder.append("userid=");
			builder.append(userid);
			builder.append(", ");
		}
		if (role != null) {
			builder.append("role=");
			builder.append(role);
		}
		builder.append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(address1, address2, city, email1, firstName, lastName, middleName, phone1, photo, role,
				staffId, state, status, userid, zipCode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Staff)) {
			return false;
		}
		Staff other = (Staff) obj;
		return Objects.equals(address1, other.address1) && Objects.equals(address2, other.address2)
				&& Objects.equals(city, other.city) && Objects.equals(email1, other.email1)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(middleName, other.middleName) && Objects.equals(phone1, other.phone1)
				&& Objects.equals(photo, other.photo) && Objects.equals(role, other.role)
				&& Objects.equals(staffId, other.staffId) && Objects.equals(state, other.state)
				&& Objects.equals(status, other.status) && Objects.equals(userid, other.userid)
				&& Objects.equals(zipCode, other.zipCode);
	}
}
