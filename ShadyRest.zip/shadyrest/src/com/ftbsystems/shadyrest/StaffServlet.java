package com.ftbsystems.shadyrest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class StaffServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/StaffServlet" })
public class StaffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/*
	 * StaffServlet.java
	 * 
	 * This servlet takes input from "StaffMultiListing" and finds the specific
	 * staff member clicked upon. It then adds that member to the request object and
	 * shoots the package to Staff.jsp.
	 * 
	 * Staff.jsp will allow the user to edit the staff member.
	 * 
	 * 
	 */
	public StaffServlet() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		if (role == null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		if (role.contentEquals("RA")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		if (role.contentEquals("ADMIN")) {
			// OK - we have the rights to change this info ...
			StaffServices nss = new StaffServices(); // fire up the old engine!
			String mystaffId = request.getParameter("StaffID"); // got an id?
			Staff myStaffMember; // make a staff member
			RequestDispatcher dispatcher; // declare a dispatcher
			if (mystaffId != null) { // if its a known id
				Long StaffID = Long.parseLong(request.getParameter("StaffID"));
				myStaffMember = nss.getStaffById(StaffID);
				request.setAttribute("StaffMember", myStaffMember);
				System.out.println("StaffServlet says: Going to update" + myStaffMember);
				dispatcher = request.getRequestDispatcher("Staff.jsp");

			} else { // if its a call for a new id
				dispatcher = request.getRequestDispatcher("StaffNewStaff.jsp");
			}
			dispatcher.forward(request, response);
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
