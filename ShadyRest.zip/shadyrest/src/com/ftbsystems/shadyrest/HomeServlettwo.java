package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Servlet implementation class HomeServlettwo
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/HomeServlettwo" })
public class HomeServlettwo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/*
	 * HomeServlettwo.java
	 * 
	 * Deprecated class.
	 * 
	 * Written by Bernard J. Girardot on January 2, 2020
	 * 
	 * Deprecated January 10, 2020
	 * 
	 */
	public HomeServlettwo() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		IncidentServices nis = new IncidentServices(); // go get the open incidents for display
		List<Incident> myIncidents = nis.getOpenIncidents();
		request.setAttribute("Incidents", myIncidents); // for display on the home status page
		ServiceServices nvs = new ServiceServices();
		List<Service> myVerbs = nvs.getRecentServices();
		request.setAttribute("Services", myVerbs); // for display on the home status page
		RequestDispatcher dispatcher = request.getRequestDispatcher("Home.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
