/**
 * 
 */
package com.ftbsystems.shadyrest;

/**
 * @author Bernard Girardot
 *
 */
/*
 * This class holds all of the valid incident and service types.
 * 
 */
public final class Constants {

	String[] IncidentTypes = { "Fell", "Fainted", "Sizure", "Choked", "Died" };
	String[] ServiceTypes = { "Escorted", "Dinning", "Room Service", "Shower", "Hygene" };

	public Constants() {

	}
}
