package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ResidentMultiListingServlet
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ResidentMultiListingServlet" })
public class ResidentMultiListingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ResidentMultiListingServlet() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/*
	 * ResidentMultiListingServlet.java
	 * 
	 * Written by Bernard J. Girardot on February 2, 2020
	 * 
	 * This routine is loosely coupled with the rest of the app, and is called by
	 * several programs (and can even be called by "Driver")
	 * 
	 * It gets a list of all of the current residents, and calls the
	 * residentMultiListing.jsp page to display them.
	 * 
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		if (role == null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		if (role.contentEquals("RA")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		if (role.contentEquals("ADMIN")) {

			ResidentServices nrs = new ResidentServices();
			List<Resident> theResidents = nrs.getAllResidents();
			request.setAttribute("Residents", theResidents);
			RequestDispatcher dispatcher = request.getRequestDispatcher("ResidentMultiListing.jsp");
			dispatcher.forward(request, response);
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
