/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.util.List;

/**
 * @author Bernard Girardot
 *
 */

/*
 * Driver.java
 * 
 * A quick stub to test classes without having to run thru the whole logon
 * ordeal.
 * 
 * Not required for the project, but makes for easy testing.
 * 
 * 
 */
public class Driver {

	/**
	 * @param args
	 */

	public void runner() {
		System.out.println("Sally was here!");

		Constants myConstants = new Constants();
		System.out.println("There are " + myConstants.IncidentTypes.length + " types of Incidents");
		for (int i = 0; i < myConstants.IncidentTypes.length; i++) {
			System.out.println(myConstants.IncidentTypes[i]);
		}
		System.out.println("There are " + myConstants.ServiceTypes.length + " types of Services");
		for (int i = 0; i < myConstants.ServiceTypes.length; i++) {
			System.out.println(myConstants.ServiceTypes[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver myDriver = new Driver();
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		myDriver.runner();
		System.out.println("Done!");

	}

}
