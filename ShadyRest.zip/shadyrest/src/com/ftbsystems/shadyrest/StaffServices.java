/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Query;

/**
 * @author Bernard Girardot
 *
 */
/*
 * @NamedQueries({
 * 
 * @NamedQuery(name="getStaffById",
 * query="SELECT s from Staff s where s.id=:Id"),
 * 
 * @NamedQuery(name="getAllStaff", query="SELECT s from Staff s") })
 */
public class StaffServices extends AbstractServices {

	public StaffServices() {

	}

	public Staff getStaffById(Long staffId) {
		Query q = em.createNamedQuery("getStaffById");
		q.setParameter("Id", staffId);
		List<Staff> myStaff = (List<Staff>) q.getResultList();
		System.out.println("Working it here boss!");
		return myStaff.get(0);
	}

	public List<Staff> getAllStaff() {
		Query q = em.createNamedQuery("getAllStaff");
		List<Staff> myStaff = (List<Staff>) q.getResultList();
		return myStaff;
	}

	public void saveStaff(Staff staff) {
		em.getTransaction().begin();
		em.persist(staff);
		em.getTransaction().commit();
	}

	private static void copyFileUsingStream(File source, Long StaffId) throws IOException {
		InputStream is = null;
		OutputStream os = null;
		Long runner = StaffId;
		String fileName = "ST-";
		while (runner < 100000) {
			fileName = fileName + "0";
			runner = runner * 10;
		}
		fileName = fileName + ".jpg";
		fileName = "./pics/" + fileName;
		System.out.println(fileName);
		File dest = new File(fileName);
		try {
			is = new FileInputStream(source);
			os = new FileOutputStream(dest);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
		} finally {
			is.close();
			os.close();
		}
	}
}
