/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Bernard Girardot
 * 
 *         Credentials object controls authentication AND authorization into the
 *         system.
 */
/*
 * This is the credentials object. It is used to hold credentials for the
 * various users.
 * 
 * It is never exposed to other tables or any other services than
 * "Credential Services"
 * 
 * 
 */
@Entity
@NamedQuery(name = "credentials.getUser", query = "SELECT c from Credentials c WHERE c.userId=:userid")
public class Credentials implements Serializable {
	private static final long serialVersionUID = 9L;
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.AUTO)
	 * 
	 * @Column(name = "id", updatable = false, nullable = false) Long id;
	 */
//	@Column(name = "create_date", columnDefinition="DATETIME")
//	@Temporal(TemporalType.TIMESTAMP)
//	private Date createDate;
	@Id
	@Column(name = "userId")
	private String userId;

	@Column(name = "password")
	private String password;

	@Column(name = "role")
	private String role;

	public Credentials() {

	}

	/**
	 * @param userId
	 * @param password
	 * @param role
	 */
	public Credentials(String userId, String password, String role) {
		this.setUserId(userId);
		this.setPassword(password);
		this.setRole(role);
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Credentials [");
		if (userId != null) {
			builder.append("userId=");
			builder.append(userId);
			builder.append(", ");
		}
		if (password != null) {
			builder.append("password=");
			builder.append(password);
			builder.append(", ");
		}
		if (role != null) {
			builder.append("role=");
			builder.append(role);
		}
		builder.append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(password, role, userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Credentials)) {
			return false;
		}
		Credentials other = (Credentials) obj;
		return Objects.equals(password, other.password) && Objects.equals(role, other.role)
				&& Objects.equals(userId, other.userId);
	}

}
