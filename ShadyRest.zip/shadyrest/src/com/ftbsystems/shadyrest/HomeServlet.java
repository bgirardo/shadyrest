package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TemporalType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mindrot.jbcrypt.BCrypt;

/**
 * 
 * Servlet implementation class HomeServlet
 * 
 */
/**
 * @author Bernard Girardot
 * 
 * */

/*
 * HomeServlet.Java
 *  
 * This servlet is called by Index.jsp.  Parameters provided are the  userid and "clear" passwword.
 * This should be called using HTTPS with appropriate credentials in a real production environment.
 * 
 * 
 * Called by:  	Index.jsp
 * Calls:		Home.jsp
 * 
 * Note:  Uses the Credentials DAO and establishes the sesssion.
 * 
 */

@WebServlet(asyncSupported = true, description = "Primary Serverlet for the home (index) page", urlPatterns = {"/HomeServlet" })
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HomeServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/* 
	 * HomeServlet.java
	 * 
	 * Called by Index
	 * 		Generates a list of the open incidents (with residents and staff)
	 * 		Generates a list of recent services (with residents and staff)
	 * 		Adds these lists to the request object
	 * 		calls home.jsp
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		String userName = request.getParameter("username");			// grab the user id from the request object
		String password = request.getParameter("password");			// and the password
		String role;												// set up some vars
		Boolean valid;
		
		
		// lets fire up a session and see if we can fly!
		HttpSession session = request.getSession();					// get a session for the users	
		
		
		// credential dao fire up!
		CredentialServices cs = new CredentialServices();			// fire up credentials persistence engine
		String salt = BCrypt.gensalt();								// gen some salt (if needed)

		
		String hashed = BCrypt.hashpw(password, salt);				// crypt the password given
		Credentials userCredentials = null;
		try {
			userCredentials = cs.getCredentials(userName);
		} catch (CredentialsMissingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	// get the password from the credentials database
		
		
		// do they exist?
		if (userCredentials == null) {								// if credentials as null - no user ... 
			System.out.println("Credentials are null!");			// send 'em back to the index page
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			dispatcher.forward(request, response);
		}

		if (userCredentials.getPassword() == null) {
			System.out.println("Null password!");
			request.setAttribute("credentials", userCredentials);
			RequestDispatcher dispatcher = request.getRequestDispatcher("Password.jsp");
			dispatcher.forward(request, response);
		}
		
		// ok - they exist, right password?
		valid = BCrypt.checkpw(password, userCredentials.getPassword());

		
		// We're looking good!  Lets start!
		if (valid != false) { // ok - we have a good user ID and Password
			session.setAttribute("user", userCredentials); // on to home page
			role = userCredentials.getRole(); // lets check - where do we send them?
			if (role.contentEquals("ADMIN")) { // admins
				session.setAttribute("role", "ADMIN");
				IncidentServices nis = new IncidentServices();
				List<Incident> myIncidents = nis.getOpenIncidents(); // go grab the open incidents
				ServiceServices nvs = new ServiceServices();
				List<Service> myServices = nvs.getRecentServices(); // get the recent services
				request.setAttribute("Incidents", myIncidents);
				request.setAttribute("Services", myServices); // for display on the home status page
				RequestDispatcher dispatcher = request.getRequestDispatcher("Home.jsp");  		// Admins get sent here
				dispatcher.forward(request, response);
			} else { // loggers (RA barcode page)
				session.setAttribute("role", "RA");
				RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp");  // RAs get sent here
				dispatcher.forward(request, response);							
			}
		} else { // back to index page - not valid id/passwd combo
				RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");	// take another shot at it jr.!
				dispatcher.forward(request, response);

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
