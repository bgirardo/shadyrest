package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StaffNewStaffPersist
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/StaffNewStaffPersist" })
public class StaffNewStaffPersist extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StaffNewStaffPersist() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Staff thisStaff = new Staff();
		thisStaff.setLastName(request.getParameter("lastname"));
		thisStaff.setFirstName(request.getParameter("firstname"));
		thisStaff.setMiddleName(request.getParameter("middlename"));
		thisStaff.setAddress1(request.getParameter("address1"));
		thisStaff.setAddress2(request.getParameter("address2"));
		thisStaff.setCity(request.getParameter("city"));
		thisStaff.setState(request.getParameter("state"));
		thisStaff.setPhone1(request.getParameter("phone1"));
		thisStaff.setEmail1(request.getParameter("email1"));
		thisStaff.setZipCode(request.getParameter("postcode"));
		thisStaff.setRole(request.getParameter("Role"));
		thisStaff.setPhoto(request.getParameter("photo"));

		// We've updated a new staff object - lets save it!
		StaffServices nss = new StaffServices();
		nss.saveStaff(thisStaff);

		// Don't forget to update the credentials table
		CredentialServices ncs = new CredentialServices();
		Credentials myCredentials = new Credentials();
		myCredentials.setRole(request.getParameter("Role"));
		myCredentials.setUserId(request.getParameter("userId")); // once set - can't be changed.
		// myCredentials.setStatus("ACTIVE");
		ncs.saveCredentials(myCredentials);

		// done! Now lets send the user back to a multi-listing page.
		List<Staff> myStaff = nss.getAllStaff();
		request.setAttribute("Staff", myStaff);
		RequestDispatcher dispatcher = request.getRequestDispatcher("StaffMultiListing.jsp"); // shoot it to the Service
																								// jsp
		dispatcher.forward(request, response); // go!

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
