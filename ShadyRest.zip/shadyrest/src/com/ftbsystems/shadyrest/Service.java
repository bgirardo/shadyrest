/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Bernard Girardot
 * 
 *         Service is the reason for the program - it tracks what services were
 *         rendered to which residents. Note that we need to annotate both the
 *         "id" and the startTime fields. Java's date type (in java.util) does
 *         not track any time information. Time information is needed by both
 *         the application as well as mysql's datetime type. Usage of startime
 *         is as follows:
 * 
 *         startTime now = LocalDateTime.now();
 *         System.out.println(dtf.format(startTime));
 *
 *
 *         Note: Some refactoring is still needed ... from time to time you will
 *         see "Verbs" in the code - Verbs became "Service" when "Incidents"
 *         were added.
 *
 */

@Entity
@Table(name = "service")
@NamedQueries({ @NamedQuery(name = "getServicesbyStaff", query = "SELECT s from Service s"),
		@NamedQuery(name = "getServicesbyResidents", query = "SELECT s from Service s"),
		@NamedQuery(name = "getAllServices", query = "SELECT s from Service s") })

// + "(UNIX_TIMESTAMP(NOW()-INTERVAL 1 DAY)))")
public class Service implements Serializable {
	private static final long serialVersionUID = 4L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "service_id", updatable = false, nullable = false)
	Long serviceId;

	@Column(name = "service")
	String Service; // This is the verb as recorded

	@Column(name = "start_time", columnDefinition = "DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date startTime;

	@Column(name = "avg_time")
	int avgTime; // how long (on average) does it take to do?

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "resident_id")
	private Resident resident;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "staff_id")
	private Staff staff;

	public Service() { // no argument constructor

	}

	/**
	 * @param serviceId
	 * @param service
	 * @param startTime
	 * @param avgTime
	 * @param resident
	 * @param staff
	 */
	public Service(String service, Date startTime, int avgTime, Resident resident, Staff staff) {

		Service = service;
		this.startTime = startTime;
		this.avgTime = avgTime;
		this.resident = resident;
		this.staff = staff;
	}

	/**
	 * @return the serviceId
	 */
	public Long getServiceId() {
		return serviceId;
	}

	/**
	 * @param serviceId the serviceId to set
	 */
	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}

	/**
	 * @return the service
	 */
	public String getService() {
		return Service;
	}

	/**
	 * @param service the service to set
	 */
	public void setService(String service) {
		Service = service;
	}

	/**
	 * @return the startTime
	 */
	public Date getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the avgTime
	 */
	public int getAvgTime() {
		return avgTime;
	}

	/**
	 * @param avgTime the avgTime to set
	 */
	public void setAvgTime(int avgTime) {
		this.avgTime = avgTime;
	}

	/**
	 * @return the resident
	 */
	public Resident getResident() {
		return resident;
	}

	/**
	 * @param resident the resident to set
	 */
	public void setResident(Resident resident) {
		this.resident = resident;
	}

	/**
	 * @return the staff
	 */
	public Staff getStaff() {
		return staff;
	}

	/**
	 * @param staff the staff to set
	 */
	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Service [");
		if (serviceId != null) {
			builder.append("serviceId=");
			builder.append(serviceId);
			builder.append(", ");
		}
		if (Service != null) {
			builder.append("Service=");
			builder.append(Service);
			builder.append(", ");
		}
		if (startTime != null) {
			builder.append("startTime=");
			builder.append(startTime);
			builder.append(", ");
		}
		builder.append("avgTime=");
		builder.append(avgTime);
		builder.append(", ");
		if (resident != null) {
			builder.append("resident=");
			builder.append(resident);
			builder.append(", ");
		}
		if (staff != null) {
			builder.append("staff=");
			builder.append(staff);
		}
		builder.append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(Service, avgTime, resident, serviceId, staff, startTime);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Service)) {
			return false;
		}
		Service other = (Service) obj;
		return Objects.equals(Service, other.Service) && avgTime == other.avgTime
				&& Objects.equals(resident, other.resident) && Objects.equals(serviceId, other.serviceId)
				&& Objects.equals(staff, other.staff) && Objects.equals(startTime, other.startTime);
	}
}
