package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServiceMultiListingServlet
 */

/*
 * @author Bernard J. Girardot
 * 
 *
 */
/*
 * ServiceMultiListingServlet.java
 * 
 * This is a "stand alone" servlet - can be called by anyone. It will request a
 * list of the services that have been rendered by the staff, and present it in
 * a mult-listing page for easy consumption.
 * 
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ServiceMultiListingServlet" })
public class ServiceMultiListingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServiceMultiListingServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		if (role == null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		if (role.contentEquals("RA")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		if (role.contentEquals("ADMIN")) {

			ServiceServices nss = new ServiceServices(); // fire up the old factory!
			List<Service> myServices = nss.getAllServices(); // grab all of the services!
			request.setAttribute("services", myServices); // add 'em to the request object
			RequestDispatcher dispatcher = request.getRequestDispatcher("ServiceMultiListing.jsp"); // send 'em to the
																									// output page
			dispatcher.forward(request, response); // done! Easy-Peasy.

			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
