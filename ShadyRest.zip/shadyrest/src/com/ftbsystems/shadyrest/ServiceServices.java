/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Query;
import javax.persistence.TemporalType;

/**
 * @author Bernard Girardot
 *
 */

/*
 * ServiceServices.java
 * 
 * This class extends the abstractServices class in order to provide persistance
 * services to the Serverice class. The namedqueries are copied here for easy
 * refernece by the developers.
 * 
 */

public class ServiceServices extends AbstractServices {
	/*
	 * @NamedQueries({
	 * 
	 * @NamedQuery(name="getServicesbyStaff",
	 * query="SELECT v from Verbs v where v.bywho=:staffId"),
	 * 
	 * @NamedQuery(name="getServicesbyResidents",
	 * query="SELECT v from Verbs v where v.towho=:residentID")
	 * 
	 * @NamedQuery(name="getAllSerivces", query="SELECT v from Verbs v") })
	 */

	public ServiceServices() {
	}

	public void saveVerbService(Service verb) {
		em.getTransaction().begin(); // save a service
		em.persist(verb);
		em.getTransaction().commit();
	}

	public List<Service> getServicesByResident(Long id) {
		Query q = em.createNamedQuery("getServicesbyResident"); // grab a service by resident (backwards query)
		q.setParameter("residentId", id);
		List<Service> theServices = q.getResultList();
		return theServices;
	}

	public List<Service> getAllServices() { // get all logged services
		Query q = em.createQuery("select s from Service s");
		// Query q=em.createNamedQuery("getAllServices");
		List<Service> myServices = q.getResultList();
		return myServices;
	}

	public List<Service> getServicesbyStaff(Long id) { // another "backwards" query - by stafff
		Query q = em.createNamedQuery("getServicesbyStaff");
		q.setParameter("staffId", id);
		List<Service> theServices = q.getResultList();
		return theServices;
	}

	public List<Service> getRecentServices() { // work is needed on this one ... we need to select by timestamp.
		Query q = em.createQuery("select s from Service s");
		// Query q=em.createNamedQuery("getAllServices");
		List<Service> myServices = q.getResultList();
		return myServices;
	}

	Instant instant = Instant.now().minus(24, ChronoUnit.HOURS);
	Timestamp timestamp = Timestamp.from(instant);

	public Service getServiceById(Long id) {
		return em.find(Service.class, id);
	}

	public void deleteService(Service service) {
		em.getTransaction().begin();
		em.remove(service);
		em.getTransaction().commit();
	}
}
