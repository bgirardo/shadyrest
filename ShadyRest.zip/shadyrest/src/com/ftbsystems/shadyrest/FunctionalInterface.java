/**
 * 
 */
package com.ftbsystems.shadyrest;

/**
 * @author Bernard Girardot
 *
 */
@java.lang.FunctionalInterface
public interface FunctionalInterface {
	Boolean passwordLength(String testPassword);

	default void saySomething() {
		System.out.println("Here's a default function!");
	}
}
