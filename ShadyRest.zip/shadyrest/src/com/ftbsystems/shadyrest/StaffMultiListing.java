package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class StaffMultiListing
 */

/*
 * StaffMultiListing.java
 * 
 * Called by misc. places - this is a "Stand Along" service uses StaffServices
 * Calls staffmultilisting.java
 * 
 * WRitten by Bernard J. Girardot on January 15, 2020
 * 
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/StaffMultiListing" })
public class StaffMultiListing extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StaffMultiListing() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		if (session != null) {
			// a session exists
			System.out.println("StaffMultiListing.java says: We have a Session!");

		} else {
			System.out.println("StaffMultiListing.java says:  Throw em back - no paperwork!");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // take another shot at it jr.!
			dispatcher.forward(request, response);
			// no session
		}
		String myRole = (String) session.getAttribute("role");
		if (!(myRole.contentEquals("ADMIN"))) {
			System.out.println("StaffMultiListingJava says:  Not an admin - back to index");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // take another shot at it jr.!
			dispatcher.forward(request, response);
			// not an admin!
		}

		StaffServices nss = new StaffServices(); // fire up the persistence factory
		List<Staff> myStaff = nss.getAllStaff(); // get the staff members
		request.setAttribute("Staff", myStaff); // add the staff members to the Request object

		RequestDispatcher dispatcher = request.getRequestDispatcher("StaffMultiListing.jsp"); // send 'em downstream
																								// tothe
																								// StaffMultiListing.jsp
		dispatcher.forward(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath()); // log it.
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
