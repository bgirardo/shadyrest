package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StaffUpdateServlet
 *
 * @web.servlet name="StaffUpdateServlet" display-name="StaffUpdateServlet"
 *              description="Manages the updating of Staff from staff.jsp"
 *
 * @web.servlet-mapping url-pattern="/StaffUpdateServlet"
 */
@WebServlet(asyncSupported = true, description = "Manages the updating of Staff from staff.jsp", urlPatterns = {
		"/StaffUpdateServlet" })
public class StaffUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StaffUpdateServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String staffId = request.getParameter("staffId");
		Long thisStaffID = Long.parseLong(staffId);
		StaffServices nss = new StaffServices();
		Staff revisedStaff = nss.getStaffById(thisStaffID);
		revisedStaff.setLastName(request.getParameter("lastname"));
		revisedStaff.setFirstName(request.getParameter("firstname"));
		revisedStaff.setMiddleName(request.getParameter("middlename"));
		revisedStaff.setAddress1(request.getParameter("address1"));
		revisedStaff.setAddress2(request.getParameter("address2"));
		revisedStaff.setCity(request.getParameter("city"));
		revisedStaff.setState(request.getParameter("state"));
		revisedStaff.setPhone1(request.getParameter("phone1"));
		revisedStaff.setEmail1(request.getParameter("email1"));
		revisedStaff.setZipCode(request.getParameter("postcode"));
		revisedStaff.setRole(request.getParameter("Role"));
		revisedStaff.setPhoto(request.getParameter("photo"));
		nss.em.getTransaction().begin();
		nss.em.persist(revisedStaff);
		nss.em.getTransaction().commit();
		response.getWriter().append("Served at: ").append(request.getContextPath());

		IncidentServices nis = new IncidentServices();
		List<Incident> myIncidents = nis.getAllIncidents(); // get the open incidents
		ServiceServices nvs = new ServiceServices();
		List<Service> myServices = nvs.getRecentServices(); // get the recent services
		request.setAttribute("Incidents", myIncidents);
		request.setAttribute("Services", myServices); // for display on the home status page
		RequestDispatcher dispatcher = request.getRequestDispatcher("Home.jsp");
		dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
