/**
 * 
 */
package com.ftbsystems.shadyrest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * @author Bernard Girardot
 *
 */
/*
 * AbstractServices.Java
 * 
 * Written by Bernard J. Girardot in Java on January 20, 2020
 * 
 * This abstract class is used by each of the service providers to save some
 * typing. It establishes an Entity Managment Factory as needed by JPA.
 * 
 * This class is extended by: CredentialServices.java IncidentServices.java
 * ServiceServices.java ResidentServices.java StaffServices.java
 */
public  abstract class AbstractServices {
	protected EntityManagerFactory emf;
	protected EntityManager em;

	public AbstractServices() {
		emf = Persistence.createEntityManagerFactory("shadyrest"); // connect to which database?
		em = emf.createEntityManager(); // create a new entity manager
	}

	public void cleanup() {
		em.close(); // not invoked often enough!
		emf.close();

	}

}
