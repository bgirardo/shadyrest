/**
 * /**
 * @author Bernard Girardot
 * 
 */

/*
 * Incident.java is the class representing incidents that can happen to residents.
 * 
 * This is an Entity managed class.
 * 
 * Note:  Incidents will almost always have a resident object and a staff object attached to them as
 * incidents happen to a resident, and a staff member always reports the incident.
 * 
 */
package com.ftbsystems.shadyrest;

/*
 * Incident.java
 * 
 * Class used to model incidents.
 * 
 * Written December 20, 2020
 * 		  
 */

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Query;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "incident")
@NamedQueries({ @NamedQuery(name = "getAllIncidents", query = "SELECT i from Incident i"),
		@NamedQuery(name = "getIncidentById", query = "SELECT i from Incident i where i.incidentId=:incidentId"),
		@NamedQuery(name = "getOpenIncidents", query = "SELECT i from Incident i where i.status=:status")

})
public class Incident implements Serializable {
	private static final long serialVersionUID = 5L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "incident_id", updatable = false, nullable = false)
	private Long incidentId;

	@Column(name = "start_time", columnDefinition = "DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date startTime;

	@Column(name = "incident")
	private String incident;

	@Column(name = "status")
	private String status;

	@Column(name = "end_Time", columnDefinition = "DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endTime;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "resident_id")
	private Resident resident;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "staff_id")
	private Staff staff;

	public Incident() {

	}

	/**
	 * @param incidentId
	 * @param startTime
	 * @param incident
	 * @param status
	 * @param endTime
	 * @param resident
	 * @param staff
	 */
	public Incident(Date startTime, String incident, String status, Date endTime, Resident resident, Staff staff) {
		this.startTime = startTime;
		this.incident = incident;
		this.status = status;
		this.endTime = endTime;
		this.resident = resident;
		this.staff = staff;
	}

	/**
	 * @return the incidentId
	 */
	public Long getIncidentId() {
		return incidentId;
	}

	/**
	 * @param incidentId the incidentId to set
	 */
	public void setIncidentId(Long incidentId) {
		this.incidentId = incidentId;
	}

	/**
	 * @return the startTime
	 */
	public Date getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the incident
	 */
	public String getIncident() {
		return incident;
	}

	/**
	 * @param incident the incident to set
	 */
	public void setIncident(String incident) {
		this.incident = incident;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the endTime
	 */
	public Date getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the resident
	 */
	public Resident getResident() {
		return resident;
	}

	/**
	 * @param resident the resident to set
	 */
	public void setResident(Resident resident) {
		this.resident = resident;
	}

	/**
	 * @return the staff
	 */
	public Staff getStaff() {
		return staff;
	}

	/**
	 * @param staff the staff to set
	 */
	public void setStaff(Staff staff) {
		this.staff = staff;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Incident [");
		if (incidentId != null) {
			builder.append("incidentId=");
			builder.append(incidentId);
			builder.append(", ");
		}
		if (startTime != null) {
			builder.append("startTime=");
			builder.append(startTime);
			builder.append(", ");
		}
		if (incident != null) {
			builder.append("incident=");
			builder.append(incident);
			builder.append(", ");
		}
		if (status != null) {
			builder.append("status=");
			builder.append(status);
			builder.append(", ");
		}
		if (endTime != null) {
			builder.append("endTime=");
			builder.append(endTime);
			builder.append(", ");
		}
		if (resident != null) {
			builder.append("resident=");
			builder.append(resident);
			builder.append(", ");
		}
		if (staff != null) {
			builder.append("staff=");
			builder.append(staff);
		}
		builder.append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(endTime, incident, incidentId, resident, staff, startTime, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Incident)) {
			return false;
		}
		Incident other = (Incident) obj;
		return Objects.equals(endTime, other.endTime) && Objects.equals(incident, other.incident)
				&& Objects.equals(incidentId, other.incidentId) && Objects.equals(resident, other.resident)
				&& Objects.equals(staff, other.staff) && Objects.equals(startTime, other.startTime)
				&& Objects.equals(status, other.status);
	}
}
