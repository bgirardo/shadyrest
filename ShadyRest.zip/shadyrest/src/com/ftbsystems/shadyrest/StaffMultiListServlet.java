package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class StaffMultiListServlet
 */
@WebServlet(asyncSupported = true, description = "Staff mulit-listing page's servlet", urlPatterns = {
		"/StaffMultiListServlet" })
public class StaffMultiListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/*
	 * StaffMultiListServlet.java
	 * 
	 * Drives the staffmultilisting.jsp page
	 * 
	 * This page simply grabs all of the staff members and provides them (via the
	 * request object) to the staffmultilisting.jsp page.
	 * 
	 * Written by Bernard J. Girardot on February 10, 2002
	 * 
	 */
	public StaffMultiListServlet() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		if (role == null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		if (role.contentEquals("RA")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		if (role.contentEquals("ADMIN")) {
			StaffServices nss = new StaffServices(); // fire up the staff serivces engine
			List<Staff> theStaff = nss.getAllStaff(); // get the members of the staff
			request.setAttribute("Staff", theStaff); // add them to the request object
			RequestDispatcher dispatcher = request.getRequestDispatcher("StaffMultiListing.jsp"); // call the display //
																									// page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
