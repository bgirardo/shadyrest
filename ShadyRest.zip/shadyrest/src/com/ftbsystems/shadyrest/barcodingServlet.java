package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class barcodingServlet
 */

/*
 * @Author Bernard J. Girardot
 * 
 */

/*
 * barcodingServlet.java
 * 
 * This Servlet takes input from the "Logging.jsp" screen, creates a new
 * Incident or Service object (as needed), seeks the resident object (and
 * insures that the resident object is currently "Managed"), seeks the staff
 * member, and then adds the staff member and resident to the newly created
 * Incident or Service. It then persists the result.
 */

@WebServlet(asyncSupported = true, urlPatterns = { "/barcodingServlet" })
public class barcodingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public barcodingServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * The barcode fields are "coded" so that the operator doesn't accidently scan
		 * the wrong information into the wrong field.
		 * 
		 * To that end, staff IDs are preceeded by "ST-" Resident IDs are preceeded by
		 * "RS-" Incidnets are preceeded by "IN-" Services are preceeded by "VB=" (which
		 * is a legacy of the original code from December 2019)
		 */

		String field1 = request.getParameter("towho"); // note - the prefix will be used to insure that the operator
		String field2 = request.getParameter("bywho"); // doesn't put the wrong scan into the wrong field!
		String field3 = request.getParameter("service");
		String[] field1split = field1.split("-"); // this is the Resident Scan
		String[] field2split = field2.split("-"); // this is the provider or staff scan
		String[] field3split = field3.split("-"); // finally -this is the type scan.

		Boolean valid = false;
		if ((field1split[0].contentEquals("RS") && (field2split[0].contentEquals("ST") && ( // We have valid "Resident
																							// and Staff" scans in the
																							// correct fields.
		(field3split[0].contentEquals("VB") || (field3split[0].contentEquals("IN"))))))) { // now - do we have an
																							// incident or a service?
			valid = true; // note: verbs is an artifact from when the app didn't have
			String staffIdTemp = field2split[1]; // 2nd field of the barcode field incoming.
			StaffServices nss = new StaffServices(); // new service
			Long staffId = Long.parseLong(staffIdTemp); // turn the string into an ID
			Staff myStaff = nss.getStaffById(staffId); // go get the id
			// ok - we now have a staff member to associate with the record ... lets do the
			// same for the residnet

			String residentIDTemp = field1split[1]; // stuff to the right of the "-" in the scan
			ResidentServices rss = new ResidentServices(); // gen up a new resident services
			Long residentID = Long.parseLong(residentIDTemp); // turn the string into a long
			Resident myResident = rss.getResidentById(residentID);
			Date date = new Date();
			Timestamp ts = new Timestamp(date.getTime()); // need to get a timestamp from the system.
			String typeOfAction = field3split[1];
			if (field3split[0].contentEquals("VB")) { // we have a service
				Service service = new Service();
				service.setResident(myResident);
				service.setStaff(myStaff);

				service.setStartTime(ts);
				service.setService(typeOfAction); // field 2 is for the action
				ServiceServices nServerService = new ServiceServices();
				nServerService.saveVerbService(service);
			} else { // we have an incident!
				Incident incident = new Incident();
				incident.setIncident(typeOfAction); // the incident type
				incident.setResident(myResident);
				incident.setStaff(myStaff);
				incident.setStartTime(ts);
				incident.setStatus("Open");
				IncidentServices nis = new IncidentServices();
				nis.saveIncident(incident);
			}
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp");
		dispatcher.forward(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
