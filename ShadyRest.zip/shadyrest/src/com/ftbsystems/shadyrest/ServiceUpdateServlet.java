package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServiceUpdateServlet
 */

/*
 * ServiceUpdateServlet.java
 * 
 * Called by Server.jsp Updates the object or enters a new object. Returns the
 * user to the ServiceMulti-Listing page
 * 
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ServiceUpdateServlet" })
public class ServiceUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServiceUpdateServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		long serviceId = Long.parseLong(request.getParameter("ServiceId")); // what Service do we need to address?

		// note: Action is a hidden field on the "Server.jsp" page. its contents are set
		// by the button pushed on that page.
		// the actions can be "Delete", "Close" and "Return"
		String action = request.getParameter("action"); // how do we want to address it?
		ServiceServices nss = new ServiceServices();
		Service thisService = nss.getServiceById(serviceId); // go grab the service in question
		List<Service> myServices = nss.getAllServices();
		request.setAttribute("services", myServices);
		RequestDispatcher dispatcher = request.getRequestDispatcher("ServiceMultiListing.jsp");
		dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
