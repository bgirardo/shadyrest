package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class IncidentUpdateServlet
 */

/*
 * IncidentUpdateServlet.java
 * 
 * This servlet listens for the inciden.jsp page and acts upon its request:
 * 
 * Delte the incident Close the incident Return to the Home page.
 * 
 * Note - Incidents can not be updated. They can only be closed or deleted.
 * 
 * Written around December 20, 2019
 * 
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/IncidentUpdateServlet" })
public class IncidentUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public IncidentUpdateServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		long incidentId = Long.parseLong(request.getParameter("incidentId"));
		String action = request.getParameter("action");
		IncidentServices nis = new IncidentServices();
		Incident thisIncident = nis.getIncidentById(incidentId);

		if (action.contentEquals("close")) {
			Date date = new Date();
			Timestamp ts = new Timestamp(date.getTime());
			thisIncident.setEndTime(ts);
			thisIncident.setStatus("Closed");
			nis.saveIncident(thisIncident);
		}
		if (action.contentEquals("delete")) {
			nis.deleteIncident(thisIncident);
		}
		if (action.contentEquals("return")) {
			// no action needed.
		}

		List<Incident> myIncidents = nis.getAllIncidents();
		request.setAttribute("incidents", myIncidents);
		RequestDispatcher dispatcher = request.getRequestDispatcher("IncidentMultiListing.jsp");
		dispatcher.forward(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
