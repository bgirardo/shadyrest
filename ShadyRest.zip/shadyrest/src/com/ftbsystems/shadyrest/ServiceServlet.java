package com.ftbsystems.shadyrest;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServiceServlet
 */

/*
 * ServiceServlet.java
 * 
 * Called by ServiceMultiListing.jsp page
 * 
 * This servlet will get a single serivce and call "service.jsp" in order to
 * present it.
 * 
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/ServiceServlet" })
public class ServiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ServiceServlet() {
		super();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		if (role == null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		if (role.contentEquals("RA")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Logging.jsp"); // call the display // page
			dispatcher.forward(request, response); // shoot 'em down the tube.
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

		if (role.contentEquals("ADMIN")) {

			String myId = request.getParameter("ServiceID"); // Get the string version of the ID from the parameter list
			Long theId = Long.parseLong(myId); // turn it into a Long ...
			ServiceServices nss = new ServiceServices(); // Fire up the persistence factory
			Service thisService = nss.getServiceById(theId); // grab the ID
			request.setAttribute("service", thisService); // add the ID to the request object
			RequestDispatcher dispatcher = request.getRequestDispatcher("Service.jsp"); // shoot it to the Service jsp
			dispatcher.forward(request, response); // go!
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
