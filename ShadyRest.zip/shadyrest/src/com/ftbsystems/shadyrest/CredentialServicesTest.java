/**
 * 
 */
package com.ftbsystems.shadyrest;

/**
 * @author Bernard Girardot
 *
 */
public class CredentialServicesTest {

}
