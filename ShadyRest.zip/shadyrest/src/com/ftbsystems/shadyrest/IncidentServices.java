/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.util.List;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Query;

/**
 * @author Bernard Girardot
 * 
 *         IncidentServices.java
 * 
 *         Written January 20, 2020
 * 
 *         This class provides DB services to for Incidents. Named queries for
 *         the class are copied here for the convenience of anyone who wishes to
 *         maintain this code.
 * 
 *         Main queries are Get Incidends by Resident (getIncidentsbyResident)
 *         Get Incidents by Staff (getIncidentsbyStaff) and Get Open Incidents
 *         (getOpenIncidents)
 * 
 *         Other fucntions provided include saveIncident.
 *
 */
/*
 * @NamedQueries({
 * 
 * @NamedQuery(name="getOpenIncidents",
 * query="SELECT i FROM Incidents i WHERE i.status=:status"),
 * 
 * @NamedQuery(name="getIncidentsbyResident",
 * query="SELECT i from Incidents i WHERE i.towho=:residentID"),
 * 
 * @NamedQuery(name="getAllIncidents", query="SELECT i from Incidents i"),
 * 
 * @NamedQuery(name="getIncidentsByStaff",
 * query="SELECT i FROM Incidents i where i.bywho=:staffID" ) })
 */

public class IncidentServices extends AbstractServices {

	public IncidentServices() {
	}

	public List<Incident> getIncidentsByResident(Long id) {
		Query q = em.createNamedQuery("getIncidentsbyResident");
		q.setParameter("residentID", id);
		List<Incident> theIncidents = q.getResultList();
		return theIncidents;
	}

	public Incident getIncidentById(Long Id) {
		return em.find(Incident.class, Id);
	}

	public List<Incident> getIncidentsByStaff(Long id) {
		Query q = em.createNamedQuery("getIncidentsbyStaff");
		q.setParameter("staffID", id);
		List<Incident> theIncidents = q.getResultList();
		return theIncidents;
	}

	public List<Incident> getOpenIncidents() {
		Query q = em.createNamedQuery("getOpenIncidents");
		q.setParameter("status", "Open");
		List<Incident> theIncidents = (List<Incident>) q.getResultList();
		return theIncidents;
	}

	public void deleteIncident(Incident incident) {
		em.getTransaction().begin();
		em.remove(incident);
		em.getTransaction().commit();
	}

	public List<Incident> getAllIncidents() {
		System.out.println("IncidentServices says:  Getting the Incidents (IncidentServices)");
		Query q = em.createNamedQuery("getAllIncidents");
		List<Incident> theIncidents = (List<Incident>) q.getResultList();
		return theIncidents;
	}

	public void saveIncident(Incident incident) {
		em.getTransaction().begin();
		em.persist(incident);
		em.getTransaction().commit();
		return;

	}
}
