/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Bernard Girardot
 * 
 *         Residents.java is the class representing the residents of the
 *         facility.
 * 
 *         Note: Residents have two lists - Incidents and Verbs.
 * 
 *         Incidents is a list of tracked incidents that the resident has faced.
 * 
 *         Verbs is a list of services that have been rendered to the resident.
 *
 */

@Entity
@Table(name = "resident")
@NamedQueries({ @NamedQuery(name = "getResidentByName", query = "SELECT r from Resident r where r.lastName=:name"),
		@NamedQuery(name = "getAllResidents", query = "SELECT r from Resident r"),
		@NamedQuery(name = "getResidentById", query = "SELECT r from Resident r where r.residentId=:residentID") })

public class Resident implements Serializable {
	private static final long serialVersionUID = 6L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "resident_id")
	private Long residentId;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "middle_name")
	private String middleName;

	@Column(name = "address1")
	private String address1;

	@Column(name = "address2")
	private String address2;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "zipcode")
	private String zipCode;

	@Column(name = "phone1")
	private String phone1;

	@Column(name = "email1")
	private String email1;

	@Column(name = "status")
	private String status;

	@Column(name = "photo")
	private String photo;

	public Resident() {

	}

	/**
	 * @param lastName
	 * @param firstName
	 * @param middleName
	 * @param address1
	 * @param address2
	 * @param city
	 * @param state
	 * @param zipCode
	 * @param phone1
	 * @param email1
	 * @param status
	 * @param photo
	 */
	public Resident(String lastName, String firstName, String middleName, String address1, String address2, String city,
			String state, String zipCode, String phone1, String email1, String status, String photo) {
		this.setLastName(lastName);
		this.setFirstName(firstName);
		this.setMiddleName(middleName);
		this.setAddress1(address1);
		this.setAddress2(address2);
		this.setCity(city);
		this.setState(state);
		this.setZipCode(zipCode);
		this.setPhone1(phone1);
		this.setEmail1(email1);
		this.setStatus(status);
		this.setPhoto(photo);
	}

	/**
	 * @return the residentId
	 */
	public Long getResidentId() {
		return residentId;
	}

	/**
	 * @param residentId the residentId to set
	 */
	public void setResidentId(Long residentId) {
		this.residentId = residentId;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1 the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2 the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the phone1
	 */
	public String getPhone1() {
		return phone1;
	}

	/**
	 * @param phone1 the phone1 to set
	 */
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	/**
	 * @return the email1
	 */
	public String getEmail1() {
		return email1;
	}

	/**
	 * @param email1 the email1 to set
	 */
	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the photo
	 */
	public String getPhoto() {
		return photo;
	}

	/**
	 * @param photo the photo to set
	 */
	public void setPhoto(String photo) {
		this.photo = photo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Resident [");
		if (residentId != null) {
			builder.append("residentId=");
			builder.append(residentId);
			builder.append(", ");
		}
		if (lastName != null) {
			builder.append("lastName=");
			builder.append(lastName);
			builder.append(", ");
		}
		if (firstName != null) {
			builder.append("firstName=");
			builder.append(firstName);
			builder.append(", ");
		}
		if (middleName != null) {
			builder.append("middleName=");
			builder.append(middleName);
			builder.append(", ");
		}
		if (address1 != null) {
			builder.append("address1=");
			builder.append(address1);
			builder.append(", ");
		}
		if (address2 != null) {
			builder.append("address2=");
			builder.append(address2);
			builder.append(", ");
		}
		if (city != null) {
			builder.append("city=");
			builder.append(city);
			builder.append(", ");
		}
		if (state != null) {
			builder.append("state=");
			builder.append(state);
			builder.append(", ");
		}
		if (zipCode != null) {
			builder.append("zipCode=");
			builder.append(zipCode);
			builder.append(", ");
		}
		if (phone1 != null) {
			builder.append("phone1=");
			builder.append(phone1);
			builder.append(", ");
		}
		if (email1 != null) {
			builder.append("email1=");
			builder.append(email1);
			builder.append(", ");
		}
		if (status != null) {
			builder.append("status=");
			builder.append(status);
			builder.append(", ");
		}
		if (photo != null) {
			builder.append("photo=");
			builder.append(photo);
		}
		builder.append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		return Objects.hash(address1, address2, city, email1, firstName, lastName, middleName, phone1, photo,
				residentId, state, status, zipCode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Resident)) {
			return false;
		}
		Resident other = (Resident) obj;
		return Objects.equals(address1, other.address1) && Objects.equals(address2, other.address2)
				&& Objects.equals(city, other.city) && Objects.equals(email1, other.email1)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(middleName, other.middleName) && Objects.equals(phone1, other.phone1)
				&& Objects.equals(photo, other.photo) && Objects.equals(residentId, other.residentId)
				&& Objects.equals(state, other.state) && Objects.equals(status, other.status)
				&& Objects.equals(zipCode, other.zipCode);
	}
}
