package com.ftbsystems.shadyrest;

public class CredentialsMissingException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CredentialsMissingException (String message) {
		super(message);
	}

}
