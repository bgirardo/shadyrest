package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ResidentUpdateServlet
 */
/*
 * ResidentUpdateServlet.java
 * 
 * As the name implies, this is the business logic and back end to Resident
 * class. The servlet is called by Resident.java and sends the user (when done)
 * to the home page (after getting the appropriate information).
 */

/*
 * This service will update a resident, or generate a new resident if the
 * ResidentID parameter is null
 * 
 */
@WebServlet(asyncSupported = true, description = "provides persistence services for the resident class.", urlPatterns = {
		"/ResidentUpdateServlet" })
public class ResidentUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ResidentUpdateServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("============!!!!!!!!!!!================");
		String idAsString = request.getParameter("ResidentID"); // do we have a residentid?
		System.out.println(idAsString);
		System.out.println(request.getParameter("ResidentID"));
		System.out.println(request.getParameter("residentId"));

		System.out.println("idAsaString =  " + idAsString); // grab the ID sent back from Resident.jsp
		ResidentServices nrs = new ResidentServices(); // fire up the old db engine
		Resident thisResident; // by getting the resident within the servlet, it becomes managed again.
		long residentId = Long.parseLong(idAsString); // convert the string to a long
		thisResident = nrs.getResidentById(residentId); // Go get the old resident!

		if (!(thisResident != null)) {
			thisResident = new Resident();
		}

		thisResident.setFirstName(request.getParameter("firstname")); // lets move the info from the web page into the
																		// object.
		thisResident.setLastName(request.getParameter("lastname"));
		thisResident.setMiddleName(request.getParameter("middlename"));
		thisResident.setAddress1(request.getParameter("address1"));
		thisResident.setAddress2(request.getParameter("address2"));
		thisResident.setCity(request.getParameter("city"));
		thisResident.setState(request.getParameter("state"));
		thisResident.setEmail1(request.getParameter("email1"));
		thisResident.setPhone1(request.getParameter("phone1"));
		thisResident.setPhoto(request.getParameter("photo"));
		thisResident.setStatus(request.getParameter("status"));

		nrs.em.getTransaction().begin(); // lets save the info!
		nrs.em.persist(thisResident);
		nrs.em.getTransaction().commit(); // done!
		response.getWriter().append("Served at: ").append(request.getContextPath());

		// now lets send 'em home.
		IncidentServices nis = new IncidentServices();
		List<Incident> myIncidents = nis.getAllIncidents(); // get the open incidents

		ServiceServices nvs = new ServiceServices();
		List<Service> myServices = nvs.getRecentServices(); // get the recent services
		request.setAttribute("Incidents", myIncidents);
		request.setAttribute("Services", myServices); // for display on the home status page
		RequestDispatcher dispatcher = request.getRequestDispatcher("Home.jsp"); // send 'em home!
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
