package com.ftbsystems.shadyrest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GenerateBarCodePage
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/GenerateBarCodePage" })
public class GenerateBarCodePage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	/*
	 * works in conjunction with the final "Constants" class.
	 * 
	 * Written on March 7, 2020
	 * 
	 */
	public GenerateBarCodePage() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Constants myConstants = new Constants();
		StaffServices nss = new StaffServices();
		List<Staff> myStaff = nss.getAllStaff(); // get all the services
		ResidentServices nrs = new ResidentServices();
		List<Resident> myResidents = nrs.getAllResidents(); // get all the residents

		List<String> myIncidents = new ArrayList<>(); // lets add the Incident constants to a list
		List<String> myServices = new ArrayList<>();
		for (int i = 0; i < myConstants.IncidentTypes.length; i++) {
			myIncidents.add(myConstants.IncidentTypes[i]);
		}
		for (int i = 0; i < myConstants.ServiceTypes.length; i++) { // same thing for Services
			System.out.println(myConstants.ServiceTypes[i]);
			myServices.add(myConstants.ServiceTypes[i]);
		}

		request.setAttribute("Staff", myStaff); // lets add all 4 types of objects to the request object
		request.setAttribute("Resident", myResidents);
		request.setAttribute("Incident", myIncidents);
		;
		request.setAttribute("Service", myServices);
		System.out.println("About to Call BarReport!");
		RequestDispatcher dispatcher = request.getRequestDispatcher("BarReport.jsp"); // load the old "Brown Bess!"
		dispatcher.forward(request, response); // FIRE!!!!!!
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
