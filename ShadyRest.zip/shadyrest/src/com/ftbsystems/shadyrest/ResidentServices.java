/**
 * 
 */
package com.ftbsystems.shadyrest;

import java.io.Serializable;
import java.util.List;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Query;

/**
 * @author Bernard Girardot
 *
 */
/*
 * ResidentServices.java
 * 
 * This class provides databases serivces for residents. It extends
 * AbstractServices
 * 
 * 
 */
/*
 * @NamedQueries({
 * 
 * @NamedQuery(name="getResidentByName",
 * query="SELECT r from Residents r where r.lastName=:name"),
 * 
 * @NamedQuery(name="getAllResidents", query="SELECT r from Residents r")
 * 
 * @NamedQuery(name="getResidentById",
 * query="SELECT r from REsidnets r where r.residentId=":residentID") })
 */

public class ResidentServices extends AbstractServices implements Serializable {
	private static final long serialVersionUID = 20L;

	public ResidentServices() {

	}

	public Resident getResidentById(Long id) {
		System.out.println("Looking for Resident: " + id);
		return em.find(Resident.class, id);
	}

	public List<Resident> getResidentbyName(String name) {
		Query q = em.createNamedQuery("getResidentByName");
		q.setParameter("name", name);
		List<Resident> theResidents = q.getResultList();
		return theResidents;
	}

	public void saveResident(Resident resident) {
		em.getTransaction().begin();
		System.out.println("Attempting to save a resident!");
		em.persist(resident);
		System.out.println("Almost done!");
		em.getTransaction().commit();
		System.out.println("Done!");
	}

	public List<Resident> getAllResidents() {
		Query q = em.createNamedQuery("getAllResidents");
		List<Resident> theResidents = q.getResultList();
		return theResidents;
	}
}
